package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {


    private lateinit var inputNumber: EditText
    private lateinit var radioGroup: RadioGroup
    private lateinit var buttonShow: Button
    private lateinit var listView: ListView
    private lateinit var errorText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputNumber = findViewById(R.id.inputNumber20)
        radioGroup = findViewById(R.id.radioGroup)
        buttonShow = findViewById(R.id.buttonShow)
        listView = findViewById(R.id.listView)
        errorText = findViewById(R.id.errorText)

        buttonShow.setOnClickListener {
            showNumbers()
        }
    }

    private fun showNumbers() {
        val input = inputNumber.text.toString()

        if (input.isEmpty() || input.toIntOrNull() == null || input.toInt() <= 0) {
            errorText.text = "Vui lòng nhập một số nguyên dương hợp lệ"
            errorText.visibility = View.VISIBLE
            return
        } else {
            errorText.visibility = View.GONE
        }

        val n = input.toInt()
        val selectedId = radioGroup.checkedRadioButtonId
        val result = when (selectedId) {
            R.id.radioEven -> getEvenNumbers(n)
            R.id.radioOdd -> getOddNumbers(n)
            R.id.radioSquare -> getSquareNumbers(n)
            else -> listOf("Vui lòng chọn một loại số")
        }

        // Hiển thị kết quả trong ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, result)
        listView.adapter = adapter
    }

    private fun getEvenNumbers(n: Int): List<String> {
        val evenNumbers = mutableListOf<String>()
        for (i in 0..n step 2) {
            evenNumbers.add(i.toString())
        }
        return evenNumbers
    }

    private fun getOddNumbers(n: Int): List<String> {
        val oddNumbers = mutableListOf<String>()
        for (i in 1..n step 2) {
            oddNumbers.add(i.toString())
        }
        return oddNumbers
    }

    private fun getSquareNumbers(n: Int): List<String> {
        val squareNumbers = mutableListOf<String>()
        var i = 0
        while (i * i <= n) {
            squareNumbers.add((i * i).toString())
            i++
        }
        return squareNumbers
    }
}
