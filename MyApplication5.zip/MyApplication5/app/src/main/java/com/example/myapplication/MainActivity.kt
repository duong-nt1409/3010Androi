package com.example.myapplication

import Student
import StudentAdapter
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    private lateinit var studentRecyclerView: RecyclerView
    private lateinit var studentAdapter: StudentAdapter
    private lateinit var searchEditText: EditText
    private var studentList: MutableList<Student> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Khởi tạo RecyclerView
        studentRecyclerView = findViewById(R.id.recyclerView)
        searchEditText = findViewById(R.id.searchInput)

        // Dữ liệu mẫu
        studentList.addAll(listOf(
            Student("Nguyen Van A", "2222"),
            Student("Tran Thi B", "2233"),
            Student("Le Van C", "2111")
        ))

        studentAdapter = StudentAdapter(studentList)
        studentRecyclerView.layoutManager = LinearLayoutManager(this)
        studentRecyclerView.adapter = studentAdapter

        // Thiết lập tìm kiếm
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filter(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filter(query: String) {
        val filteredList = studentList.filter {
            it.name.contains(query, ignoreCase = true) || it.mssv.contains(query, ignoreCase = true)
        }
        studentAdapter.updateList(filteredList)
    }
}
