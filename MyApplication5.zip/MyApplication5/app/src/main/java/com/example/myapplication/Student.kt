data class Student(
    val name: String,
    val mssv: String
)
